<template>
<div class="blog">
	<h1>Blog</h1>
	<Cards :cards="blogPosts"></Cards>
</div>
</template>

<style scoped lang='scss'>


</style>

<script>
	import blogPosts from '@/data/blogPosts.js';
	import Cards from "@/components/Cards.vue";


	export default {
		components: {
			Cards
		},
		layout: 'wide',
		data() {
			return {
				blogPosts
			}
		},
	}
</script>


<style>


</style>