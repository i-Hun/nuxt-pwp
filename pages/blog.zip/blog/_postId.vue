<template>
	<section class="ipynb-post">
		<h1 class="title">{{post.title}}</h1>
		<IpynbCells :cells="cells" :language="language"></IpynbCells>
		<References :references="references"></References>
		<Comments :pagePath="$nuxt.$route.path"></Comments>
	</section>
</template>

<script>
import IpynbCells from "@/components/IpynbCells.vue";
import References from "@/components/References.vue";
import Comments from "@/components/Comments.vue";
import Card from "@/components/Card.vue";
import axios from 'axios';
const cheerio = require('cheerio');
import blogPosts from '@/data/blogPosts.js';


export default {
	components: {
		IpynbCells,
		Comments,
		References,
		Card
	},
	head () {
		const title = `${this.post.title}`;
		const description = this.post.description ? description : "";
		return {
			title: title,
			meta: [
				{
					hid: 'description',
					name: 'description',
					content: description
				},
				{
					hid: 'og:title',
					property: 'og:title',
					content: title
				},
				{
					hid: 'og:image',
					property: 'og:image',
					content: this.post.img ? this.post.img : '/img/cover.jpg'
				},
				{
					hid: 'og:description',
					property: 'og:description',
					content: description
				},
				{
					hid: 'author',
					name: 'author',
					content: this.post.author ? this.post.author : "Oleg Nagornyy"
				},
			]
		}
	},
	async asyncData (context) {
		let notebook = undefined;

		if (process.browser) {
			notebook = axios({
				method: 'get',
				timeout: 1000,
				url: notebookPath
			}).then(res => {
				console.log("res.data", res.data)
				return res.data
			})
			console.log("notebook", notebook)
		} else {
			notebook = JSON.parse(require('fs').readFileSync(`/Users/hun/pwp-v3/static/blog/${context.params.postId}.ipynb`, 'utf-8'))
		}
		let cells = notebook["cells"];

		let references = {};

		cells =	cells.map(cell => {
			if (cell.cell_type === "markdown") {
				let cell_text = cell.source.join('')
				var regex = /\[.*?\]\(https:\/\/www.zotero.org\/.*?\)/g;
				let regex2 = /\(https:\/\/www.zotero.org\/.*?\)/g;
				var found_refs = cell_text.match(regex2);

				if (found_refs) {
					for (let found_ref of found_refs){
						found_ref = found_ref.slice(1, -1)
						if (!references.hasOwnProperty(found_ref)) {
							references[found_ref] = Object.keys(references).length + 1;
						}	
					}
				}

				for (let reference of Object.keys(references)) {

					cell_text = cell_text.replace(new RegExp(`\\(${reference}\\)`, 'gi'), `<a href='#ref-${references[reference]}' class='intext-ref'>[${references[reference]}]</a>`)
				}

				cell.source = cell_text
				return cell;
			} else return cell
		})


		let promises = Object.entries(references).map(ref => {
			let url = ref[0];
			let order = ref[1];

			let refId = url.split('/')[url.split('/').length-1];


			return axios.get(`https://www.zotero.org/api/users/2770884/items/${refId}?format=bib&style=apa&linkwrap=1`)
			.then(response => {
				const $ = cheerio.load(response.data);

				return {"order": order, "data": $('.csl-entry').html()};
			})
			.catch(e => {
				console.error(e);
			})
		})


		let refs = await Promise.all(promises);


		let thisPost = null;

		for (let post of blogPosts) {
			if (post.id === context.params.postId) {
				thisPost = post;
			} 
		}

		return {
			cells: cells,
			references: refs.filter(el => {return el != null}),
			post: thisPost,
			language: notebook['metadata']['kernelspec']['language']
		}

	}
}
</script>

<style lang="scss">
.meta {
	font-size: 0.75rem;
	color: #666;
}
.breadcrumb {
	margin-top: 30px;
}

</style>
